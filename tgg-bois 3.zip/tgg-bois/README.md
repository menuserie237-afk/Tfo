# TGG Bois

Démarrage local :
1. `npm install`
2. `cp .env.example .env` puis renseignez VITE_SUPABASE_PUBLISHABLE_KEY
3. `npm run dev`

Les migrations SQL (001 à 004) ont été exécutées dans Supabase SQL Editor.
