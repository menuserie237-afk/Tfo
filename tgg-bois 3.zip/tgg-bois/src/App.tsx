import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { AdminRoute, GuestRoute, ProtectedRoute } from './routes/guards';
import { isSupabaseConfigured } from './lib/supabase';
import { useI18n } from './i18n';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import Forgot from './pages/auth/Forgot';
import Reset from './pages/auth/Reset';
import ShopLayout from './components/ShopLayout';
import Home from './pages/shop/Home';
import Catalog from './pages/shop/Catalog';
import ProductDetail from './pages/shop/ProductDetail';
import AdminLayout from './pages/admin/AdminLayout';
import Overview from './pages/admin/Overview';
import Products from './pages/admin/Products';
import ProductForm from './pages/admin/ProductForm';
import Categories from './pages/admin/Categories';

function MissingConfig() {
  const { t } = useI18n();
  return (
    <main className="grid min-h-screen place-items-center p-6">
      <div className="max-w-md rounded-3xl bg-white p-8 shadow-card">
        <h1 className="text-2xl text-forest">{t('config.missing.title')}</h1>
        <p className="mt-2 text-forest/70">{t('config.missing.body')}</p>
      </div>
    </main>
  );
}

export default function App() {
  if (!isSupabaseConfigured) return <MissingConfig />;
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route element={<GuestRoute />}>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<Forgot />} />
          </Route>
          <Route path="/reset-password" element={<Reset />} />
          <Route element={<ProtectedRoute />}>
            <Route element={<ShopLayout />}>
              <Route path="/" element={<Home />} />
              <Route path="/catalog" element={<Catalog />} />
              <Route path="/product/:id" element={<ProductDetail />} />
            </Route>
            <Route element={<AdminRoute />}>
              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<Overview />} />
                <Route path="products" element={<Products />} />
                <Route path="products/new" element={<ProductForm />} />
                <Route path="products/:id/edit" element={<ProductForm />} />
                <Route path="categories" element={<Categories />} />
              </Route>
            </Route>
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
