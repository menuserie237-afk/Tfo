import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { fr, type Key } from './fr';
import { en } from './en';

export type Lang = 'fr' | 'en';
const STORAGE_KEY = 'tgg_lang';
const dicts: Record<Lang, Record<Key, string>> = { fr, en };

interface I18nValue { lang: Lang; setLang: (l: Lang) => void; toggle: () => void; t: (k: Key) => string; }
const I18nContext = createContext<I18nValue | null>(null);

function initialLang(): Lang {
  try { const s = localStorage.getItem(STORAGE_KEY); if (s === 'fr' || s === 'en') return s; } catch { /* ignore */ }
  return 'fr'; // français par défaut
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(initialLang);
  useEffect(() => {
    document.documentElement.lang = lang;
    try { localStorage.setItem(STORAGE_KEY, lang); } catch { /* ignore */ }
  }, [lang]);
  const t = useCallback((k: Key) => dicts[lang][k] ?? k, [lang]);
  const value = useMemo<I18nValue>(() => ({
    lang, setLang: setLangState, toggle: () => setLangState((l) => (l === 'fr' ? 'en' : 'fr')), t,
  }), [lang, t]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n doit être utilisé dans I18nProvider');
  return ctx;
}

/** Traduit une erreur Supabase Auth en message clair. */
export function authErrorKey(err: { message?: string; status?: number } | null): Key {
  const m = (err?.message || '').toLowerCase();
  if (m.includes('invalid login')) return 'err.invalidCredentials';
  if (m.includes('not confirmed')) return 'err.emailNotConfirmed';
  if (m.includes('already registered') || m.includes('already been registered')) return 'err.alreadyRegistered';
  if (m.includes('rate limit') || err?.status === 429) return 'err.rateLimit';
  if (m.includes('fetch') || m.includes('network')) return 'err.network';
  return 'err.generic';
}
