import { WHATSAPP_NUMBER } from './config';

/** Construit un lien wa.me. Retourne null si le numéro configuré est invalide. */
export function whatsappUrl(message: string): string | null {
  if (!/^\d{8,15}$/.test(WHATSAPP_NUMBER)) return null;
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
