import { useEffect, useState } from 'react';
import { supabase } from './supabase';

export type Availability = 'in_stock' | 'made_to_order' | 'unavailable';
export interface Product {
  id: number; name: string | null; description: string | null; price: number | null; category: string | null;
  image_url: string | null; stock: number; is_active: boolean; availability: Availability; created_at: string;
}
export interface Category { id: number; slug: string; name_fr: string; name_en: string; sort_order: number }
export interface ProductImage { id: number; product_id: number; storage_path: string; url: string; sort_order: number }

export const formatPrice = (p: number | null) => (p == null ? null : `${new Intl.NumberFormat('fr-FR').format(p)} FCFA`);
export const catName = (c: Category, lang: 'fr' | 'en') => (lang === 'fr' ? c.name_fr : c.name_en);

// Hook générique : vrais appels Supabase, avec états de chargement et d'erreur.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function useQuery<T>(fetcher: () => PromiseLike<{ data: any; error: { message: string } | null }>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let off = false;
    setLoading(true); setError(null);
    Promise.resolve(fetcher()).then(({ data, error }) => {
      if (off) return;
      if (error) setError(error.message); else setData(data as T);
      setLoading(false);
    });
    return () => { off = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tick, ...deps]);
  return { data, error, loading, reload: () => setTick((t) => t + 1) };
}

/** all=false : vitrine (produits actifs uniquement). all=true : administration. */
export const useProducts = (all = false) =>
  useQuery<Product[]>(() => {
    let q = supabase.from('products').select('*').order('created_at', { ascending: false });
    if (!all) q = q.eq('is_active', true);
    return q;
  }, [all]);

export const useCategories = () => useQuery<Category[]>(() => supabase.from('categories').select('*').order('sort_order'), []);
