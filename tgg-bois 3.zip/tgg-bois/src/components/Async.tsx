import type { ReactNode } from 'react';
import { useI18n } from '../i18n';

export default function Async({ loading, error, onRetry, children }: { loading: boolean; error: string | null; onRetry: () => void; children: ReactNode }) {
  const { t } = useI18n();
  if (loading) return <div className="grid min-h-40 place-items-center text-forest/60" role="status">{t('common.loading')}</div>;
  if (error) return (
    <div role="alert" className="rounded-2xl bg-red-50 p-6 text-center text-red-800">
      <p>{t('common.error')}</p>
      <button onClick={onRetry} className="mt-3 rounded-full bg-forest px-5 py-2 text-sm font-medium text-ivory">{t('common.retry')}</button>
    </div>
  );
  return <>{children}</>;
}
