import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { authErrorKey, useI18n } from '../../i18n';
import { Button, Field, Notice } from '../../components/ui';
import AuthLayout, { isEmail } from './AuthLayout';

export default function Forgot() {
  const { t } = useI18n();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (!isEmail(email)) return setError(t('val.emailRequired'));
    setLoading(true);
    const { error: err } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/reset-password` });
    setLoading(false);
    if (err) return setError(t(authErrorKey(err)));
    setDone(true);
  }

  return (
    <AuthLayout title={t('auth.forgot.title')} subtitle={t('auth.forgot.subtitle')}>
      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        <Field id="email" type="email" autoComplete="email" label={t('auth.email')} value={email} onChange={(e) => setEmail(e.target.value)} />
        {error && <Notice kind="error">{error}</Notice>}
        {done && <Notice kind="success">{t('auth.forgot.success')}</Notice>}
        <Button type="submit" loading={loading}>{t('auth.forgot.send')}</Button>
        <Link to="/login" className="block py-2 text-center text-sm font-medium text-forest hover:underline">{t('auth.backToLogin')}</Link>
      </form>
    </AuthLayout>
  );
}
