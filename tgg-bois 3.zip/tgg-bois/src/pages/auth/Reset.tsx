import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { authErrorKey, useI18n } from '../../i18n';
import { Button, Notice, PasswordField } from '../../components/ui';
import AuthLayout from './AuthLayout';

// Le lien reçu par e-mail ouvre une session de récupération (gérée par Supabase) : on la vérifie.
export default function Reset() {
  const { t } = useI18n();
  const { session, loading: authLoading } = useAuth();
  const nav = useNavigate();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (password.length < 8) return setError(t('val.passwordMin'));
    setLoading(true);
    const { error: err } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (err) return setError(t(authErrorKey(err)));
    setDone(true);
    setTimeout(() => nav('/', { replace: true }), 1500);
  }

  return (
    <AuthLayout title={t('auth.reset.title')} subtitle={t('auth.reset.subtitle')}>
      {authLoading ? <p role="status">{t('common.loading')}</p> : !session ? (
        <div className="space-y-4">
          <Notice kind="error">{t('auth.reset.noSession')}</Notice>
          <Link to="/forgot-password" className="block"><Button type="button">{t('auth.forgot.send')}</Button></Link>
        </div>
      ) : (
        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          <PasswordField id="password" autoComplete="new-password" label={t('auth.newPassword')} value={password} onChange={(e) => setPassword(e.target.value)} />
          {error && <Notice kind="error">{error}</Notice>}
          {done && <Notice kind="success">{t('auth.reset.success')}</Notice>}
          <Button type="submit" loading={loading}>{t('auth.reset.save')}</Button>
        </form>
      )}
    </AuthLayout>
  );
}
