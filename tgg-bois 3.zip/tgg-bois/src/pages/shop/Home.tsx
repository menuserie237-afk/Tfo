import { Link } from 'react-router-dom';
import { useI18n } from '../../i18n';
import { catName, useCategories, useProducts } from '../../lib/data';
import { whatsappUrl } from '../../lib/whatsapp';
import Async from '../../components/Async';
import ProductCard from '../../components/ProductCard';

export default function Home() {
  const { t, lang } = useI18n();
  const cats = useCategories();
  const prods = useProducts();
  const wa = whatsappUrl(t('wa.generic'));
  return (
    <>
      {/* Photo : placez votre image dans public/hero.jpg (fond vert si absente) */}
      <section className="bg-forest-dark bg-cover bg-center" style={{ backgroundImage: "linear-gradient(90deg,rgba(22,44,34,.92),rgba(22,44,34,.5)),url('/hero.jpg')" }}>
        <div className="mx-auto max-w-6xl px-4 py-20 md:py-32">
          <h1 className="max-w-2xl text-4xl leading-tight text-ivory md:text-6xl">{t('hero.title')}</h1>
          <p className="mt-5 max-w-xl text-lg text-ivory/80">{t('hero.subtitle')}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link to="/catalog" className="rounded-full bg-ivory px-7 py-3.5 text-center font-medium text-forest hover:bg-white">{t('hero.cta1')}</Link>
            {wa && <a href={wa} target="_blank" rel="noopener noreferrer" className="rounded-full border border-ivory/60 px-7 py-3.5 text-center font-medium text-ivory hover:bg-white/10">{t('hero.cta2')}</a>}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14">
        <h2 className="mb-6 text-3xl text-forest">{t('sec.categories')}</h2>
        <Async loading={cats.loading} error={cats.error} onRetry={cats.reload}>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
            {(cats.data ?? []).map((c) => (
              <Link key={c.id} to={`/catalog?cat=${c.slug}`} className="rounded-2xl border-l-4 border-wood bg-cream p-5 font-serif text-lg text-forest transition hover:bg-sand">{catName(c, lang)}</Link>
            ))}
          </div>
        </Async>
      </section>

      <section className="bg-cream py-14">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-6 flex items-end justify-between"><h2 className="text-3xl text-forest">{t('sec.popular')}</h2><Link to="/catalog" className="text-sm font-medium text-forest underline-offset-4 hover:underline">{t('sec.all')}</Link></div>
          <Async loading={prods.loading} error={prods.error} onRetry={prods.reload}>
            {(prods.data ?? []).length === 0
              ? <p className="rounded-2xl bg-white p-8 text-center text-forest/70">{t('catalog.empty.body')}</p>
              : <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">{(prods.data ?? []).slice(0, 8).map((p) => <ProductCard key={p.id} p={p} />)}</div>}
          </Async>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-4 py-14 md:grid-cols-2">
        <div className="rounded-3xl bg-forest p-8 text-ivory"><h2 className="text-2xl">{t('sec.craft')}</h2><p className="mt-3 text-ivory/80">{t('craft.body')}</p></div>
        <div className="rounded-3xl bg-sand p-8"><h2 className="text-2xl text-forest">{t('sec.stock')}</h2><p className="mt-3 text-forest/80">{t('stock.body')}</p></div>
      </section>

      <section className="mx-auto max-w-3xl px-4 pb-16 text-center">
        <h2 className="text-3xl text-forest">{t('sec.about')}</h2>
        <p className="mt-3 text-forest/80">{t('about.body')}</p>
        <p className="mt-4 font-medium">{t('contact.addr')}</p>
      </section>
    </>
  );
}
