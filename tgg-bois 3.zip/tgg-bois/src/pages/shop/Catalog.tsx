import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useI18n } from '../../i18n';
import { catName, useCategories, useProducts } from '../../lib/data';
import Async from '../../components/Async';
import ProductCard from '../../components/ProductCard';

export default function Catalog() {
  const { t, lang } = useI18n();
  const [sp, setSp] = useSearchParams();
  const cat = sp.get('cat') || '';
  const [q, setQ] = useState('');
  const [sort, setSort] = useState('new');
  const prods = useProducts();
  const cats = useCategories();

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    let l = (prods.data ?? []).filter((p) => (!cat || p.category === cat) && (!needle || `${p.name} ${p.description}`.toLowerCase().includes(needle)));
    if (sort === 'asc') l = [...l].sort((a, b) => (a.price ?? 0) - (b.price ?? 0));
    if (sort === 'desc') l = [...l].sort((a, b) => (b.price ?? 0) - (a.price ?? 0));
    return l;
  }, [prods.data, cat, q, sort]);

  const chip = (active: boolean) => `whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium ${active ? 'bg-forest text-ivory' : 'bg-cream text-forest hover:bg-sand'}`;
  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-4xl text-forest">{t('catalog.title')}</h1>
      <div className="mt-6 flex flex-col gap-3 md:flex-row">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('catalog.search')} aria-label={t('catalog.search')} className="h-12 flex-1 rounded-xl bg-white px-4 shadow-card focus:outline-none" />
        <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label={t('catalog.sort')} className="h-12 rounded-xl bg-white px-4 shadow-card">
          <option value="new">{t('sort.new')}</option><option value="asc">{t('sort.asc')}</option><option value="desc">{t('sort.desc')}</option>
        </select>
      </div>
      <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
        <button className={chip(!cat)} onClick={() => setSp({})}>{t('catalog.all')}</button>
        {(cats.data ?? []).map((c) => <button key={c.id} className={chip(cat === c.slug)} onClick={() => setSp({ cat: c.slug })}>{catName(c, lang)}</button>)}
      </div>
      <div className="mt-6">
        <Async loading={prods.loading} error={prods.error} onRetry={prods.reload}>
          {(prods.data ?? []).length === 0
            ? <div className="rounded-3xl bg-white p-10 text-center shadow-card"><h2 className="text-2xl text-forest">{t('catalog.empty.title')}</h2><p className="mt-2 text-forest/70">{t('catalog.empty.body')}</p></div>
            : list.length === 0 ? <p className="py-10 text-center text-forest/70">{t('catalog.noResults')}</p>
            : <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">{list.map((p) => <ProductCard key={p.id} p={p} />)}</div>}
        </Async>
      </div>
    </div>
  );
}
