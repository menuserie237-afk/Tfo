import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useI18n } from '../../i18n';
import { catName, useCategories, type Availability, type ProductImage as Img } from '../../lib/data';
import { supabase } from '../../lib/supabase';
import { Button, Field, Notice } from '../../components/ui';

const MAX = 5 * 1024 * 1024;
const TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const sel = 'h-12 w-full rounded-xl bg-stone-100/80 px-4 text-base focus:bg-white focus:outline-none';

export default function ProductForm() {
  const { t, lang } = useI18n();
  const nav = useNavigate();
  const rawId = useParams().id;
  const id = rawId ? Number(rawId) : null;
  const cats = useCategories();
  const [f, setF] = useState({ name: '', description: '', price: '', stock: '0', category: '', availability: 'in_stock' as Availability, is_active: true });
  const [existing, setExisting] = useState<Img[]>([]);
  const [removed, setRemoved] = useState<Img[]>([]);
  const [files, setFiles] = useState<{ file: File; preview: string }[]>([]);
  const [errs, setErrs] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<{ kind: 'error' | 'success'; text: string } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    (async () => {
      const { data: p } = await supabase.from('products').select('*').eq('id', id).maybeSingle();
      if (p) setF({ name: p.name ?? '', description: p.description ?? '', price: p.price == null ? '' : String(p.price), stock: String(p.stock), category: p.category ?? '', availability: p.availability, is_active: p.is_active });
      const { data: im } = await supabase.from('product_images').select('*').eq('product_id', id).order('sort_order');
      setExisting(im ?? []);
    })();
  }, [id]);
  useEffect(() => () => files.forEach((x) => URL.revokeObjectURL(x.preview)), []); // eslint-disable-line

  function pick(list: FileList | null) {
    if (!list) return;
    const ok: typeof files = []; let bad = false;
    Array.from(list).forEach((file) => { if (TYPES.includes(file.type) && file.size <= MAX) ok.push({ file, preview: URL.createObjectURL(file) }); else bad = true; });
    setFiles((x) => [...x, ...ok]);
    setErrs((e) => ({ ...e, file: bad ? t('f.err.file') : '' }));
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault(); setMsg(null);
    const er: Record<string, string> = {};
    if (f.name.trim().length < 2) er.name = t('f.err.name');
    const price = f.price.trim() === '' ? null : Number(f.price);
    if (price !== null && (!Number.isFinite(price) || price < 0)) er.price = t('f.err.price');
    const stock = Number(f.stock);
    if (!Number.isInteger(stock) || stock < 0) er.stock = t('f.err.stock');
    setErrs(er);
    if (Object.keys(er).length) return;
    setSaving(true);
    try {
      const row = { name: f.name.trim(), description: f.description.trim() || null, price, stock, category: f.category || null, availability: f.availability, is_active: f.is_active, updated_at: new Date().toISOString() };
      let pid = id;
      if (pid) { const { error } = await supabase.from('products').update(row).eq('id', pid); if (error) throw error; }
      else { const { data, error } = await supabase.from('products').insert(row).select('id').single(); if (error) throw error; pid = data.id; }

      if (removed.length) {
        await supabase.storage.from('product-images').remove(removed.map((r) => r.storage_path));
        const { error } = await supabase.from('product_images').delete().in('id', removed.map((r) => r.id)); if (error) throw error;
      }
      const rows = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i].file;
        const path = `${pid}/${crypto.randomUUID()}.${(file.name.split('.').pop() || 'jpg').toLowerCase()}`;
        const up = await supabase.storage.from('product-images').upload(path, file, { contentType: file.type });
        if (up.error) throw up.error;
        rows.push({ product_id: pid, storage_path: path, url: supabase.storage.from('product-images').getPublicUrl(path).data.publicUrl, sort_order: existing.length + i });
      }
      if (rows.length) { const { error } = await supabase.from('product_images').insert(rows); if (error) throw error; }
      const main = existing[0]?.url ?? rows[0]?.url ?? null;
      const { error } = await supabase.from('products').update({ image_url: main }).eq('id', pid); if (error) throw error;
      setMsg({ kind: 'success', text: t('f.saved') });
      setTimeout(() => nav('/admin/products'), 900);
    } catch {
      setMsg({ kind: 'error', text: t('f.err.save') });
    } finally { setSaving(false); }
  }

  const set = (k: string) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }));
  return (
    <form onSubmit={onSubmit} noValidate className="mx-auto max-w-2xl space-y-5 rounded-3xl bg-white p-6 shadow-card">
      <h1 className="text-3xl text-forest">{id ? t('f.edit') : t('f.new')}</h1>
      <Field id="name" label={t('f.name')} value={f.name} onChange={set('name')} error={errs.name} />
      <div><label htmlFor="desc" className="mb-1.5 block text-sm font-medium">{t('f.description')}</label>
        <textarea id="desc" rows={4} value={f.description} onChange={set('description')} className="w-full rounded-xl bg-stone-100/80 p-4 focus:bg-white focus:outline-none" /></div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="price" type="number" inputMode="numeric" min="0" label={t('f.price')} value={f.price} onChange={set('price')} error={errs.price} />
        <Field id="stock" type="number" inputMode="numeric" min="0" label={t('f.stock')} value={f.stock} onChange={set('stock')} error={errs.stock} />
        <div><label htmlFor="cat" className="mb-1.5 block text-sm font-medium">{t('f.category')}</label>
          <select id="cat" value={f.category} onChange={set('category')} className={sel}><option value="">—</option>{(cats.data ?? []).map((c) => <option key={c.id} value={c.slug}>{catName(c, lang)}</option>)}</select></div>
        <div><label htmlFor="av" className="mb-1.5 block text-sm font-medium">{t('f.availability')}</label>
          <select id="av" value={f.availability} onChange={set('availability')} className={sel}>{(['in_stock', 'made_to_order', 'unavailable'] as const).map((a) => <option key={a} value={a}>{t(`avail.${a}`)}</option>)}</select></div>
      </div>
      <label className="flex items-center gap-3"><input type="checkbox" checked={f.is_active} onChange={(e) => setF((s) => ({ ...s, is_active: e.target.checked }))} className="h-5 w-5 accent-forest" />{t('f.active')}</label>
      <div>
        <label htmlFor="imgs" className="mb-1.5 block text-sm font-medium">{t('f.images')}</label>
        <input id="imgs" type="file" accept={TYPES.join(',')} multiple onChange={(e) => { pick(e.target.files); e.target.value = ''; }} className="block w-full text-sm" />
        {errs.file && <p className="mt-1 text-sm text-red-700">{errs.file}</p>}
        <div className="mt-3 flex flex-wrap gap-3">
          {existing.map((im) => (<div key={im.id} className="relative"><img src={im.url} alt="" className="h-20 w-20 rounded-xl object-cover" />
            <button type="button" aria-label={t('f.removeImg')} onClick={() => { setExisting((x) => x.filter((y) => y.id !== im.id)); setRemoved((r) => [...r, im]); }} className="absolute -right-2 -top-2 h-6 w-6 rounded-full bg-red-600 text-xs text-white">×</button></div>))}
          {files.map((x, i) => (<div key={x.preview} className="relative"><img src={x.preview} alt="" className="h-20 w-20 rounded-xl object-cover ring-2 ring-forest" />
            <button type="button" aria-label={t('f.removeImg')} onClick={() => { URL.revokeObjectURL(x.preview); setFiles((l) => l.filter((_, j) => j !== i)); }} className="absolute -right-2 -top-2 h-6 w-6 rounded-full bg-red-600 text-xs text-white">×</button></div>))}
        </div>
      </div>
      {msg && <Notice kind={msg.kind}>{msg.text}</Notice>}
      <div className="flex gap-3"><Link to="/admin/products" className="w-1/3"><Button type="button" variant="outline">{t('f.cancel')}</Button></Link><Button type="submit" loading={saving}>{t('f.save')}</Button></div>
    </form>
  );
}
