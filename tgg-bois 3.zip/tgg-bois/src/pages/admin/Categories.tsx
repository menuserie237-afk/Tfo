import { useI18n } from '../../i18n';
import { catName, useCategories } from '../../lib/data';
import Async from '../../components/Async';

export default function Categories() {
  const { t, lang } = useI18n();
  const cats = useCategories();
  return (
    <div className="space-y-4">
      <h1 className="text-3xl text-forest">{t('admin.categories')}</h1>
      <p className="text-sm text-forest/70">{t('admin.categories.note')}</p>
      <Async loading={cats.loading} error={cats.error} onRetry={cats.reload}>
        <ul className="divide-y divide-sand rounded-3xl bg-white p-3 shadow-card">{(cats.data ?? []).map((c) => (
          <li key={c.id} className="flex justify-between px-3 py-3"><span className="font-medium">{catName(c, lang)}</span><code className="text-sm text-forest/60">{c.slug}</code></li>))}</ul>
      </Async>
    </div>
  );
}
