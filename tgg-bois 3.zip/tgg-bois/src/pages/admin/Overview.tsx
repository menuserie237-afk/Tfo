import { Link } from 'react-router-dom';
import { useI18n } from '../../i18n';
import { formatPrice, useCategories, useProducts } from '../../lib/data';
import Async from '../../components/Async';

// Statistiques réelles, calculées à partir des données Supabase. Aucune vente ni revenu inventé.
export default function Overview() {
  const { t } = useI18n();
  const prods = useProducts(true);
  const cats = useCategories();
  const all = prods.data ?? [];
  const active = all.filter((p) => p.is_active);
  const out = active.filter((p) => p.availability === 'unavailable' || (p.availability === 'in_stock' && p.stock === 0));
  const recent = all.filter((p) => Date.now() - new Date(p.created_at).getTime() < 30 * 864e5);
  const stats = [[t('stats.active'), active.length], [t('stats.categories'), cats.data?.length ?? 0], [t('stats.outOfStock'), out.length], [t('stats.recent'), recent.length]] as const;
  return (
    <div className="space-y-6">
      <h1 className="text-3xl text-forest">{t('admin.overview')}</h1>
      <Async loading={prods.loading || cats.loading} error={prods.error || cats.error} onRetry={() => { prods.reload(); cats.reload(); }}>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map(([label, n]) => <div key={label} className="rounded-2xl bg-white p-5 shadow-card"><p className="text-sm text-forest/70">{label}</p><p className="mt-2 font-serif text-4xl text-forest">{n}</p></div>)}
        </div>
        <div className="rounded-3xl bg-white p-5 shadow-card">
          <h2 className="mb-3 text-xl text-forest">{t('admin.latest')}</h2>
          {all.length === 0 ? <p className="text-forest/70">{t('admin.empty')}</p> : (
            <ul className="divide-y divide-sand">{all.slice(0, 5).map((p) => (
              <li key={p.id} className="flex justify-between py-3"><Link to={`/admin/products/${p.id}/edit`} className="font-medium hover:underline">{p.name}</Link><span className="text-sm text-forest/70">{formatPrice(p.price)}</span></li>
            ))}</ul>
          )}
        </div>
      </Async>
    </div>
  );
}
